if (interactive()) {
  brapiConnectAddin()
}
