# braou 1.0.0

- first version

# brapi 0.0.9.9014 2017-02-02

- Added a `NEWS.md` file to track changes to the package.
- Added examples for each function
- Added cross-references between funcions


