if (interactive()) {
      con <- ba_connect()
      con
}
