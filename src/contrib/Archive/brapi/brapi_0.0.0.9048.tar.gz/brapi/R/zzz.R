.onLoad <- function(libname = find.package("brapi"), pkgname = "brapi") {
  crops <<- c("cassava", "potato", "sweetpotato")

  brapi <<- NULL

}
