
brapi_host = "http://sgn:eggplant@sweetpotatobase-test.sgn.cornell.edu"
brapi_port = 80

#  brapi_port = 3000
#  brapi_host = "192.168.56.101"


set_brapi(brapi_host, brapi_port)
brapi_auth("rsimon16", "sweetpotato")


