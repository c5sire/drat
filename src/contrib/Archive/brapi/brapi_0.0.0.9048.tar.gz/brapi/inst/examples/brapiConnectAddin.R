if (interactive()) {
  brapiConnectAddin()
}
