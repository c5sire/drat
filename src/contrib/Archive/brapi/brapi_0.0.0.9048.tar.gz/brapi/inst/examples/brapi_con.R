
# construct a sample object
library(brapi)
