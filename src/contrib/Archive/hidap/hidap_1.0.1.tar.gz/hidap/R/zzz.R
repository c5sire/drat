# .onLoad <- function(libname = find.package("hidap"), pkgname = "hidap") {
#   start()
# }
