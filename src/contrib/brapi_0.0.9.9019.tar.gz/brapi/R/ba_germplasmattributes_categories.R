#' ba_germplasmattributes_categories
#'
#' attibutes call.
#'
#' @param con brapi connection object
#' @param page integer; default 0
#' @param pageSize integer; default 10
#' @param rclass character; default: tibble
#'
#' @return rclass as set by parameter
#' @example inst/examples/ex-ba_germplasmattributes_categories.R
#' @import httr
#' @author Reinhard Simon
#' @references \href{https://github.com/plantbreeding/API/blob/master/Specification/GermplasmAttributes/ListAttributeCategories.md}{github}
#' @family germplasmattributes
#' @family genotyping
#' @export
ba_germplasmattributes_categories <- function(con = NULL, page = 0, pageSize = 10, rclass = "tibble") {
    ba_check(con, FALSE)
    check_paging(pageSize, page)
    check_rclass(rclass)

    brp <- get_brapi(con)
    attributes_categories_list <- paste0(brp, "attributes/categories/")
    if (is.numeric(page) & is.numeric(pageSize)) {
        attributes_categories_list <- paste0(attributes_categories_list, "?page=", page, "&pageSize=", pageSize)
    }
    try({
        res <- brapiGET(attributes_categories_list, con = con)
        res <- httr::content(res, "text", encoding = "UTF-8")
        out <- dat2tbl(res, rclass)
        class(out) <- c(class(out), "ba_germplasmattributes_categories")
        return(out)
    })
}
