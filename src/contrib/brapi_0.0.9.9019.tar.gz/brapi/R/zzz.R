.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome to the 'brapi' package!\n")
}

.onLoad <- function(libname, pkgname){

}
