if (interactive()) {
      con <- ba_connect()
      ba_crops(con)
}
