library(testthat)
library(brapi)

test_check("brapi")
