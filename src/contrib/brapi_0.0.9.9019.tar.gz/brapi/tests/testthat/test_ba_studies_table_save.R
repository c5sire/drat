source("check_server_status.R")

if (check_server_status == 200) {


context("Testing the path 'studies/{id}/table' using POST")



test_that("Parameters work", {
  con <- ba_connect()
  con$bms <- TRUE
  out <- ba_login(con)

  df <- as.data.frame(cbind(
    observationUnitDbId = 1:2, # obligatory variable
    collector = c("T1", "T2"), # obligatory variable
    observationTimestamp = c("ts 1", "ts 2"), # obligatory variable
    variable1Id = c(3, 4)
  ))


  expect_true(ba_studies_table_save(out, "1",  study_table = df))

  expect_error(ba_studies_table_save(out, "1", 1))

})


}
