---
title: "Basic Tutorial"
author: "Reinhard Simon"
date: "2016-12-07"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{Vignette Title}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
---

--------------------------------------------------------------
This package is under development. It has not yet been exhaustively tested for all calls neither. Usage may also still change. If you have suggestions please use the issue tracker.
--------------------------------------------------------------

Content has been removed - docuentation needs to be re-done.


```




