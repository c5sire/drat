onLoad <- function(libname = find.package("brapps"), pkgname = "brapps") {
  crops <<- c("cassava", "potato", "sweetpotato")

  brapi <<- NULL
}
