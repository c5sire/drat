# fbanalysis
[![Build Status](https://travis-ci.org/omarbenites/fbanalysis.svg?branch=master)](https://travis-ci.org/omarbenites/fbanalysis)

[![Build status](https://ci.appveyor.com/api/projects/status/2bgigtr0dnfvmgbx?svg=true)](https://ci.appveyor.com/project/omarbenites/fbanalysis)

Interface package for HiDAP analysis

