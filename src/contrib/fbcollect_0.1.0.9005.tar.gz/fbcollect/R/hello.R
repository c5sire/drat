
#' hello
#'
#' @return string
#' @export
#'
#' @examples
#'
#' library(fbcollect)
#'
#' hello()
#'
hello <- function(){
  "Hi"
}