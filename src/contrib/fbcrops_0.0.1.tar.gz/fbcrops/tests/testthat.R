library(testthat)
library(fbcrops)

test_check("fbcrops")
