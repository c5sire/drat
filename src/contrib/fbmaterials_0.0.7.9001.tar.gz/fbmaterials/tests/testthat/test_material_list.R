context("Material lists")
#
# tbl_new <- new_materials_table()
# tbl_get <- get_material_table("potato", 2000, "aaaa")

test_that("Dummy table is created.", {
  # expect_true(is.data.frame(tbl_new), TRUE)
  # expect_true(is.data.frame(tbl_get), TRUE)
})

test_that("Summary statistics on materiasl are returned", {
  #expect_true(, TRUE)
})
