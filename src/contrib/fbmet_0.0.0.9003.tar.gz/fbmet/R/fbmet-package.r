#' fbmet.
#'
#' @name fbmet
#' @docType package
NULL
