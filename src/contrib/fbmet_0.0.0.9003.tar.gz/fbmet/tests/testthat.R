library(testthat)
library(fbmet)

test_check("fbmet")
