# fbopenbooks
A package to administrate and open fieldbooks in HiDAP.
It will make a list of all the fieldbooks created, then select your fieldbok and finally open it pressing a <OPEN-BUTTON>.

