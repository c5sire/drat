#' fbsites.
#'
#' Provides some tools to manage field site data.
#'
#' @name fbsites
#' @docType package
NULL
