# pvs
The package for participatory varietal selection under Mother&amp;Baby methodology
