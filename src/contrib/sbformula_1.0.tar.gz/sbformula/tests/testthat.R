library(testthat)
library(sbformula)

test_check("sbformula")
