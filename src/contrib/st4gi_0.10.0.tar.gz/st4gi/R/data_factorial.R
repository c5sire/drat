#' @name asc
#' @title Data for a 2-factor factorial with a CRD
#' @docType data
#' @aliases asc
#' @description This data set contains data for ascorbic acid content in mg/100g dry weight
#' (\code{asc.dw}), ascorbic acid content in mg/100g fresh weight (\code{asc.fw}), and
#' dry matter percentage (\code{dm}) for an experiment with 46 potato genotypes (\code{geno}),
#' 2 treatments (\code{treat}), cooked and crude, and 3 replications (\code{rep}) with a CBD.
#' @usage asc
#' @format A data frame with 6 columns and 282 rows.
#' @source International Potato Center, potato experimental data.
NULL
