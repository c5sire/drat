library(testthat)
library(st4gi)

test_check("st4gi")
