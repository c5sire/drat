library(testthat)
library(traittools)

test_check("traittools")
